/* Een lijst met de icoontjes van de Clickers. */
clickerIcons = [
    "https://pngimg.com/uploads/chef/chef_PNG54.png",
    /* tier 1 */
    /* tier 2 */
    /* tier 3 */
    /* tier 4 */
]

/* === De volgende functies beïnvloeden het uiterlijk van de pagina. === */

/* Voeg een nieuw icoontje toe aan de lijst met Actieve Clickers van tier tier */
function voegActieveClickerToe(tier) {

}

/* Verander het geld bedrag dat op de pagina word weergegeven naar hoeveelheid. */
function updateGeld(hoeveelheid) {

}

/* Verander het geld per seconde bedrag dat op de pagina word weergegeven naar hoeveelheid. */
function updateGeldPerSeconde(hoeveelheid) {

}

/* Verwijder de Powerup voor tier tier uit de lijst. */
function verwijderPowerup(tier) {

}

/* === Vanaf hier focussen we op de functionaliteit! === */

/* Zet alle variabelen die je nodig hebt hier. */

/* Voegt 1$ toe en update de pagina */
function onClickCookie() {

}

/* Berekent het geld dat de Clickers genereren per seconde. */
function berekenGeldPerSeconde() {

}

/* Koopt een Powerup, mits hier geld voor is en de powerup nog niet gekocht is. Update de pagina. */
function koopPowerup(tier) {

}

/* Koopt een Clicker, mits hier geld voor is en er nog ruimte is. Update de pagina. */
function koopClicker(tier) {

}

/* Voegt het geld van de Clickers toe aan het geld. Update de pagina. */
function updateClickerGeld() {

}

/* Zorgt dat updateClickerGeld elke seconde activeert. */
setInterval(updateClickerGeld, 1000)
